package com.lti.spring_jpa.dao;

import java.util.List;

import com.lti.spring_jpa.spring_jpa.Person;

public interface PersonDao 
{
void add(Person person);

	List<Person> listPersons();
	
 void delete(Long pid);
 
 List<Person> deletePersons();

}
