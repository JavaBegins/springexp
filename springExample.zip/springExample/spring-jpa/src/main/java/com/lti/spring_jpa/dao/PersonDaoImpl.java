package com.lti.spring_jpa.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.lti.spring_jpa.spring_jpa.Person;

@Repository
public class PersonDaoImpl implements PersonDao
{
@PersistenceContext
private EntityManager em;

public void add(Person person)
{
	em.persist(person);
}

public List<Person> listPersons()
{
	CriteriaQuery<Person> cq=em.getCriteriaBuilder().createQuery(Person.class);
	Root<Person> r=cq.from(Person.class);
	return em.createQuery(cq).getResultList();
}

public void delete(Long pid) {
	// TODO Auto-generated method stub
	
}

public List<Person> deletePersons() {
	// TODO Auto-generated method stub
	return null;
}




}
