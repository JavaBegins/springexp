package com.lti.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScans;
import org.springframework.context.annotation.Configuration;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalEntityManagerFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableTransactionManagement
@ComponentScans(value={ @ComponentScan("com.lti.spring_jpa"),@ComponentScan("com.lti.spring_jpa")})

public class AppConfig {
	
@Bean
public LocalEntityManagerFactoryBean geEntityManagerFactoryBean()
{
LocalEntityManagerFactoryBean fb=new LocalEntityManagerFactoryBean();
fb.setPersistenceUnitName("VICKY");
return fb;
}

@Bean
public JpaTransactionManager geJpaTransactionManager() {
	JpaTransactionManager tm=new JpaTransactionManager();
	tm.setEntityManagerFactory(geEntityManagerFactoryBean().getObject());
	return tm;
}
}
