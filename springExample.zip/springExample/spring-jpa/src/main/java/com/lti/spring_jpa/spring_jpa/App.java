package com.lti.spring_jpa.spring_jpa;

import java.sql.SQLException;
import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.lti.configuration.AppConfig;
import com.lti.spring_jpa.service.PersonService;

public class App 
{
    public static void main( String[] args ) throws SQLException
    {
       AnnotationConfigApplicationContext c= new AnnotationConfigApplicationContext(AppConfig.class);
       PersonService ps= c.getBean(PersonService.class);
       
       ps.add(new Person("Ankita","Chandrakant",23));
       ps.add(new Person("Athira","Sk",23));
       ps.add(new Person("ErmamadTiru","Gorila",23));
       ps.add(new Person("Kavya","K",23));
       
       
       List <Person> persons=ps.listPersons();
       for(Person person:persons)
       {
           System.out.println( "Id="+person.getPid() );
           System.out.println( "First Name="+person.getFname() );
           System.out.println( "Last Name="+person.getLname() );
           System.out.println( "Email="+person.getAge() );
           System.out.println();
           


           
   	
       }

       c.close();
       }
    }

