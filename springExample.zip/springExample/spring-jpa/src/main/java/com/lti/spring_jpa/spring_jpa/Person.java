package com.lti.spring_jpa.spring_jpa;

import javax.persistence.*;

@Entity
@Table(name="person")
public class Person 
{
@Id
@Column(name="pid")
@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="pp_seq")
@SequenceGenerator(name="pp_seq",sequenceName="pp_seq1",allocationSize=1)
private  long pid;


@Column(name="fname")
private String fname;

@Column(name="lname")
private String lname;

@Column(name="age")
private int age;

public Person() {
	super();
}

public Person(long pid, String fname, String lname, int age) {
	super();
	this.pid = pid;
	this.fname = fname;
	this.lname = lname;
	this.age = age;
}

public Person(String fname, String lname, int age) {
	super();
	this.fname = fname;
	this.lname = lname;
	this.age = age;
}

public long getPid() {
	return pid;
}

public void setPid(long pid) {
	this.pid = pid;
}

public String getFname() {
	return fname;
}

public void setFname(String fname) {
	this.fname = fname;
}

public String getLname() {
	return lname;
}

public void setLname(String lname) {
	this.lname = lname;
}

public int getAge() {
	return age;
}

public void setAge(int age) {
	this.age = age;
}

@Override
public String toString() {
	return "Person [pid=" + pid + ", fname=" + fname + ", lname=" + lname + ", age=" + age + "]";
}



}
