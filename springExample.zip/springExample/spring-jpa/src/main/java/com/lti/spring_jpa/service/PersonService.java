package com.lti.spring_jpa.service;

import java.util.List;

import com.lti.spring_jpa.spring_jpa.Person;

public interface PersonService 
{
void add(Person person);
List<Person> listPersons();
}

