package com.lti.springrel;

public class Car 
{
Wheel w;
public void setWheel(Wheel w)
{
	this.w=w;
}
public Wheel getWheel()
{
	return w;
}
public void move()
{
	w.rotate();
}

}
