package com.lti.collegeexp;

public class EmpDetail 
{
	public void sal(int s)
	{
		System.out.println("Salary " +s);
		int pf=s*2;
		int gf=s*5;
		System.out.println("Salary pf " +pf);
		System.out.println("Salary gf " +gf);

	}
}
