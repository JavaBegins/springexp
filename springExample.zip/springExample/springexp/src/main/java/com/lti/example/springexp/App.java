package com.lti.example.springexp;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
       AbstractApplicationContext c=new ClassPathXmlApplicationContext("beans.xml");
       HelloWorld bean=(HelloWorld) c.getBean("helloWorldBean");
       bean.printMessage("hey how are you");
       HelloWorld bean1=(HelloWorld) c.getBean("helloWorldBean");
      abc a=(abc) c.getBean("helloWorldBean");
      a.message(78,67);
       c.close();
    }
}
