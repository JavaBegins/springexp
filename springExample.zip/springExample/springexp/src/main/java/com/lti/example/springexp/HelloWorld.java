package com.lti.example.springexp;

public interface HelloWorld
{
	public void printMessage(String message);
	
	
}
