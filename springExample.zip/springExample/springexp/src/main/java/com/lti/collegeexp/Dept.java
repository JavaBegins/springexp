package com.lti.collegeexp;

public interface Dept 
{
	public void sal(int s);
}
