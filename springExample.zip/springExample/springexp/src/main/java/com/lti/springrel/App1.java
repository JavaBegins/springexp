package com.lti.springrel;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.lti.example.springexp.HelloWorld;
import com.lti.example.springexp.abc;

public class App1 
{
	 public static void main( String[] args )
	    {
	       AbstractApplicationContext c=new ClassPathXmlApplicationContext("ath.xml");
	       Car bean=(Car) c.getBean("athira");
	       bean.move();
	    //   HelloWorld bean1=(HelloWorld) c.getBean("helloWorldBean");
	    //  abc a=(abc) c.getBean("helloWorldBean");
	   //   a.message(78,67);
	       c.close();
	    }
}
