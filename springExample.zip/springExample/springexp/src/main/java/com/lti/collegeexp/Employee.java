package com.lti.collegeexp;



public class Employee
{
Dept e;

public void setDept(Dept e)
{
	this.e=e;
}
public Dept getDept()
{
	return e;
}
public void add()
{
	e.sal(5000);
}
}
