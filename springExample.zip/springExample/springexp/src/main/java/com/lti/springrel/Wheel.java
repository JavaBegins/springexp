package com.lti.springrel;

public interface Wheel 
{
void rotate();

}
