package com.lti.springrel;

public class Carimpl implements Wheel
{

	 public void rotate()
	{
		System.out.println("the wheel has been rotated");
	}


}