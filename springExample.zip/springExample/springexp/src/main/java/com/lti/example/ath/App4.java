package com.lti.example.ath;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.lti.collegeexp.Employee;

public class App4 
{
	public static void main( String[] args )
    {
       AbstractApplicationContext c=new ClassPathXmlApplicationContext("exp.xml");
       Trainee bean=(Trainee) c.getBean("ank");
       System.out.println(bean.getTname());
    }
}
