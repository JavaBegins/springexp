package com.lti.example.springexp;

public class HelloWorldImpl implements HelloWorld ,abc
{
public void printMessage(String message )
{
	System.out.println(message);
	
}
public void message(int a,int b)
{
	
	int c=a+b;
	System.out.println("a+b ="+c);
}
}
