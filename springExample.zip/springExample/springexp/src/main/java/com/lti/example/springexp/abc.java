package com.lti.example.springexp;

public interface abc 
{
	public void message(int a,int b);
}
