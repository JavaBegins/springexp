package com.lti.jdbcexp.springjdbc;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.lti.springservice.PersonService;
import com.lti.springservice.PersonServiceImpl;

public class App 
{
    public static void main( String[] args )
    {
       AbstractApplicationContext c=new AnnotationConfigApplicationContext(AppConfig.class);
       PersonService personService=(PersonService) c.getBean("ps");
       Person Kapil=new Person(4,"Kapil","Dev",64);
       Person Sachin=new Person(5,"Sachin","Tendulkar",44);
       Person Virat=new Person(6,"Virat","Kohli",33);
        
       personService.addPerson(Kapil);       
       personService.addPerson(Sachin);
       personService.addPerson(Virat);

       System.out.println("Find ALL");
       List<Person> persons=personService.findAll();
       for(Person person:persons){
           System.out.println(person);

       }
       System.out.println("Delete person Id=3");
       int deleteMe=3;
       personService.deletePerson(deleteMe);
       
       Kapil.setFname("Kapil-Updated");
       Kapil.setLname("Paaji-Updated");
       Kapil.setAge(65);
       
       System.out.println("Update person Id=1");
       int updateMe=1;
       personService.editPerson(Kapil,updateMe);
       System.out.println("Find person id=2");
       Person person=personService.find(2);
       System.out.println(person);
       
       System.out.println("Find All Again");
       persons=personService.findAll();
       for(Person p:persons){
    	   System.out.println(p);
       }
      c.close(); 
}
}
