package com.lti.springDAO;

import java.util.List;

import com.lti.jdbcexp.springjdbc.Person;

public interface PersonDAO
{
public void addPerson(Person person);
public void editPerson(Person person,int pid);
public void deletePerson(int pid);
public Person find(int pid);
public List<Person> findAll();

}
