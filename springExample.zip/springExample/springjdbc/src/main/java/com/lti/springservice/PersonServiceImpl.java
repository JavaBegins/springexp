package com.lti.springservice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.jdbcexp.springjdbc.Person;
import com.lti.springDAO.PersonDAO;

@Service("ps")
public class PersonServiceImpl implements PersonService
{
@Autowired
PersonDAO pd;

public void addPerson(Person person)
{
	pd.addPerson(person);
}

public void editPerson(Person person, int pid) 
{
	pd.editPerson( person, pid);
}

public void deletePerson(int pid) 
{
	pd.deletePerson(pid);
}

public Person find(int pid) 
{
	return pd.find(pid);
}

public List<Person> findAll() 
{
	return pd.findAll();
}

}
