package com.lti.springservice;

import java.util.List;

import org.springframework.stereotype.Component;

import com.lti.jdbcexp.springjdbc.Person;


public interface PersonService 
{
	public void addPerson(Person person);
	public void editPerson(Person person,int pid);
	public void deletePerson(int pid);
	public Person find(int pid);
	public List<Person> findAll();

}
