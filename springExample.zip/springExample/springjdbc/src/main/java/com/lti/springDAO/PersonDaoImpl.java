package com.lti.springDAO;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.lti.jdbcexp.springjdbc.Person;


@Repository
@Qualifier("personDao")
public class PersonDaoImpl implements PersonDAO
{
	
@Autowired
JdbcTemplate jt;


public void addPerson(Person person)
{
	jt.update("insert into person(pid,fname,"+" lname,age)values(?,?,?,?)",person.getPid(),person.getFname(),person.getLname(),person.getAge());
	System.out.println(" Person Added\n");
}

public void editPerson(Person person, int pid) 
{
	jt.update("update person set fname=?,lname=?,age=? where pid=?",person.getFname(),person.getLname(),person.getAge(),pid);
	System.out.println(" Person Updated\n");

}

public void deletePerson(int pid) 
{
	jt.update("delete from person where pid=?",pid);
	System.out.println(" Person Deleted\n");

}

@SuppressWarnings("rawtypes")
public Person find(int pid)
{
	@SuppressWarnings("unchecked")
	Person p=(Person)jt.queryForObject("select * from "+"person where pid=?", new Object[]{pid},new BeanPropertyRowMapper(Person.class));
	return p;
}

@SuppressWarnings("rawtypes")
public List<Person> findAll() 
{
	@SuppressWarnings("unchecked")
	List<Person> p1=jt.query("select * from person", new BeanPropertyRowMapper(Person.class));
	return p1;
}
}
