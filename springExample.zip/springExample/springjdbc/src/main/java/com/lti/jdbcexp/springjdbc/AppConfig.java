package com.lti.jdbcexp.springjdbc;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

@Configuration
@ComponentScan("com.lti.jdbcexp.springjdbc")
@PropertySource(value={"classpath:application.properties"})

public class AppConfig 
{
@Autowired
private Environment env;

@Bean
public DataSource ds()
{
	DriverManagerDataSource ds=new DriverManagerDataSource();
	ds.setDriverClassName(env.getRequiredProperty("jdbc.driverClassName"));
	ds.setUrl(env.getRequiredProperty("jdbc.url"));
	ds.setUsername(env.getRequiredProperty("jdbc.username"));
	ds.setPassword(env.getRequiredProperty("jdbc.password"));
	return ds;
}

@Bean
public JdbcTemplate jt(DataSource ds)
{
	JdbcTemplate jt=new JdbcTemplate(ds);
	jt.setResultsMapCaseInsensitive(true);
	return jt;
}


}
