package com.lti.example.annotatnXp;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

public class App 
{
    public static void main( String[] args)
    {
    	ApplicationContext c=new AnnotationConfigApplicationContext(ConfigApp.class);
    	Country countryobj=(Country)c.getBean("student");
    	Stud s=(Stud)c.getBean("college");
    	String cname=countryobj.getSname();
    	int sid=countryobj.getSid();
    	String clg=s.getCollege();
    	System.out.println("Student name "+cname+ "\n Student Id "+sid);
    	System.out.println("College Name " +clg);
    }
}
