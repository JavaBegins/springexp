package com.lti.example.annotatnXp;

public class Country 
{
String sname;
int sid;

public Country(String sname, int sid) {
	
	this.sname = sname;
	this.sid = sid;
	
}
public String getSname() {
	return sname;
}
public void setSname(String sname) {
	this.sname = sname;
}
public int getSid() {
	return sid;
}
public void setSid(int sid) {
	this.sid = sid;
}


@Override
public String toString() {
	return "Country [sname=" + sname + ", sid=" + sid +  "]";
}


}
