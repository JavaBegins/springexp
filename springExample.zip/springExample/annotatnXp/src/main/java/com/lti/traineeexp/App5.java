package com.lti.traineeexp;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.lti.example.annotatnXp.ConfigApp;

public class App5 
{
	public static void main( String[] args )
{
	ApplicationContext c=new ClassPathXmlApplicationContext("bean1.xml");
	Trainees obj = (Trainees)c.getBean("neha");
	System.out.println(obj);
}
}
