package com.lti.example.annotatnXp;

public class Stud
{
String college;

public Stud(String college) {
	
	this.college = college;
}

public String getCollege() {
	return college;
}

public void setCollege(String college) {
	this.college = college;
}

@Override
public String toString() {
	return "Stud [college=" + college + "]";
}

}
