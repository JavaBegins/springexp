package com.lti.example.annotatnXp;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ConfigApp 
{
@Bean(name="student")
public Country getCountry()
{
	return new Country("ankita",101);
	
}
@Bean(name="college")
public Stud getStud()
{
	return new Stud("bmsit");
	
}

}
