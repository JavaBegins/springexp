package com.lti.collectionexp;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;

public class CollectionBean
{
	
@Autowired
private List<String> namelist;

public  void printnamelist()
{
	System.out.println(namelist);
}

 

}
