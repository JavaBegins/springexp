package com.lti.springdependency.springdepend;

import java.util.Scanner;

public class EmpImpl implements Employee
{
	public void showEmployeeInfo()
	{
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the name\n");
		String um;
		um=in.nextLine(); 
		System.out.println("Student name : " +um);
	}

}
