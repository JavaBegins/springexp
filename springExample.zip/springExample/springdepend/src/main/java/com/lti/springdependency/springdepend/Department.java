package com.lti.springdependency.springdepend;

public interface Department 
{
void showDepartmentInfo();
}
