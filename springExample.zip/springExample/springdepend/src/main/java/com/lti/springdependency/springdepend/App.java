package com.lti.springdependency.springdepend;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
        AnnotationConfigApplicationContext c= new AnnotationConfigApplicationContext(AppConfig.class);
        Company cp=c.getBean(Company.class);
        cp.showDepartmentInfo();
        cp.showEmployeeInfo();

        c.close();
    }
}
