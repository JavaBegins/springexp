package com.lti.springdependency.springdepend;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Company 
{
private Employee emp;
private Department dept;

@Autowired
public Company(Employee emp)
{
	this.emp = emp;
}
public void showEmployeeInfo()
{
	emp.showEmployeeInfo();
}

@Autowired
public void setDepartment(Department dept)
{
	this.dept=dept;
}
public void showDepartmentInfo()
{
	dept.showDepartmentInfo();
}
}
