package com.lti.collectionexp;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class CollectionMain 
{
	 public static void main( String[] args )
	    {
		 ApplicationContext c=new AnnotationConfigApplicationContext(CollectionConfig.class);
		 CollectionBean cb=c.getBean(CollectionBean.class);
		 cb.printnamelist();
	
	    }
}
