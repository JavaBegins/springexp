package com.lti.springdependency.springdepend;

import java.util.Scanner;

public class DeptImpl implements Department
{
	public void showDepartmentInfo()
	{
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the department name\n");
		String temp;
		temp=in.nextLine(); 
		System.out.println("department : " +temp);

	}
}
