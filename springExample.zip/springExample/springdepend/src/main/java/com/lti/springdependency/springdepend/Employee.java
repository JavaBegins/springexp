package com.lti.springdependency.springdepend;

public interface Employee 
{
void showEmployeeInfo();
}
