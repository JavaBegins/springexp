package com.lti.springmodel;

public class HelloWorld
{
private String message;
private String datetime;
public String getMessage() {
	return message;
}
public void setMessage(String message) {
	this.message = message;
}
public String getDatetime() {
	return datetime;
}
public void setDatetime(String datetime) {
	this.datetime = datetime;
}

}
