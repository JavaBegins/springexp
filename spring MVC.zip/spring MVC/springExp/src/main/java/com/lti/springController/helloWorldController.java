package com.lti.springController;

import java.time.LocalDateTime;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.lti.springmodel.HelloWorld;

@Controller
public class helloWorldController 
{
@RequestMapping("/helloworld")
public String handler(Model model)
{
	HelloWorld hw= new HelloWorld();
	hw.setMessage("heyyyyyyyy");
	hw.setDatetime(LocalDateTime.now().toString());
	model.addAttribute("helloworld",hw);
	return "helloworld";
	
}
}
