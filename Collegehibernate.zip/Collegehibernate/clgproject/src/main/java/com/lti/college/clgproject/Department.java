package com.lti.college.clgproject;

import java.util.List;

import javax.persistence.*;

@Entity
@Table(name="dept1")
public class Department {
	@Id
	@Column(name="DEPTID")
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="GEN1")
	@SequenceGenerator(name="GEN1",sequenceName="dept_seq",allocationSize=1)
	
	private int deptid;
	
	

	

	public void setInstructor(List<Instructor> instructor) {
		this.instructor = instructor;
	}

	@Column(name="DEPTNAME")
	private String deptname;
	

	@Column(name="INSTID")
	@OneToMany(targetEntity=Instructor.class,mappedBy="department",cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	private List<Instructor> instructor;
	
	@Column(name="STUDENTNAME")
	@OneToMany(targetEntity=Student.class,mappedBy="department",cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	private List<Student> students;
	
	
	@OneToMany(targetEntity=Course.class,mappedBy="department",cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	private List<Course> course;
	
	public List<Student> getStudents() {
		return students;
	}

	public void setStudents(List<Student> students) {
		this.students = students;
	}

	public Department() {
		
	}

	public int getDeptid() {
		return deptid;
	}

	public void setDeptid(int deptid) {
		this.deptid = deptid;
	}

	public String getDeptname() {
		return deptname;
	}

	public void setDeptname(String deptname) {
		this.deptname = deptname;
	}

	
	public List<Instructor> getInstructor() {
		return instructor;
	}

	@Override
	public String toString() {
		return "Department [deptid=" + deptid + ", deptname=" + deptname + ", instructor=" + instructor + ", students="
				+ students + ", course=" + course + "]";
	}

	public List<Course> getCourse() {
		return course;
	}

	public void setCourse(List<Course> course) {
		this.course = course;
	}

	public Department(int deptid, String deptname, List<Instructor> instructor, List<Student> students,
			List<Course> course) {
		super();
		this.deptid = deptid;
		this.deptname = deptname;
		this.instructor = instructor;
		this.students = students;
		this.course = course;
	}

	


	

	

	
	
	
	

}

