package com.lti.college.clgproject;

import javax.persistence.*;

public class App 
{
    public static void main( String[] args )
    {
    	EntityManagerFactory emf=Persistence.createEntityManagerFactory("persistence");
        EntityManager em=emf.createEntityManager();
        
        System.out.println("Starting Transaction");
        em.getTransaction().begin();
        
        Department dept=new Department();
        dept.setDeptname("IT");
        
        Department dept1=new Department();
        dept1.setDeptname("CIVIL");
        
        Department dept3=new Department();
        dept3.setDeptname("MECH");
        
        System.out.println("Saving to database");
        
        em.persist(dept);
        em.persist(dept1);
        em.persist(dept3);
        
        Student student=new Student();
        student.setStudentname("Ankitha");
        student.setDepartment(dept);
        
        Student student1=new Student();
        student1.setStudentname("Athira");
        student1.setDepartment(dept1);
        
        Student student2=new Student();
        student2.setStudentname("Neha");
        student2.setDepartment(dept);
        
        Student student4=new Student();
        student4.setStudentname("Kavya");
        student4.setDepartment(dept1);
        
        Student student5=new Student();
        student5.setStudentname("Tiru");
        student5.setDepartment(dept3);
        
        Student student6=new Student();
        student6.setStudentname("Vicky");
        student6.setDepartment(dept3);
        
        em.persist(student1);
        em.persist(student2);
       
        em.persist(student4);
        em.persist(student5);
        em.persist(student6);
        
        
        
        
        System.out.println("Saving to database");
        
     
        
        
        
        
      Instructor instructor=new Instructor();
        instructor.setInstname("Rashi");
        instructor.setDepartment(dept);;
        
        Instructor instructor1=new Instructor();
        instructor1.setInstname("Shalini");
        instructor1.setDepartment(dept1);
      
        Instructor instructor2=new Instructor();
        instructor2.setInstname("Dharani");
        instructor2.setDepartment(dept3);
        
        Instructor instructor3=new Instructor();
        instructor3.setInstname("Rishabh");
        instructor3.setDepartment(dept1);
        
        Instructor instructor4=new Instructor();
        instructor4.setInstname("Mughul");
        instructor4.setDepartment(dept1);
        
        Instructor instructor5=new Instructor();
        instructor5.setInstname("Ifraz");
        instructor5.setDepartment(dept);
        
        Instructor instructor6=new Instructor();
        instructor6.setInstname("Rashmi");
        instructor6.setDepartment(dept3);
        
        System.out.println("Saving to database");
        em.persist(instructor);
        em.persist(instructor1);
        em.persist(instructor2);
        em.persist(instructor3);
        em.persist(instructor4);
        em.persist(instructor5);
        em.persist(instructor6);
        
        Course course1=new Course();
        course1.setCoursename("EEE");
        course1.setDepartment(dept1); 
        
        Course course2=new Course();
        course2.setCoursename("ECE");
        course2.setDepartment(dept); 
        
        Course course3=new Course();
        course3.setCoursename("MCA");
        course3.setDepartment(dept3); 
        
        Course course4=new Course();
        course4.setCoursename("IT");
        course4.setDepartment(dept1); 
        
        em.persist(course1);
        em.persist(course2);
        em.persist(course3);
        em.persist(course4);
        
        
        em.getTransaction().commit();
        em.close();
        emf.close();
        
        
        
        
        
        
        
        
        
    
    }
}
